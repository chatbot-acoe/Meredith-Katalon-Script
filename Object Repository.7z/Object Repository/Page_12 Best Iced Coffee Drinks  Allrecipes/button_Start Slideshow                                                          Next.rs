<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Start Slideshow                                                          Next</name>
   <tag></tag>
   <elementGuidId>bafe80c4-4837-4ff7-b1f6-8113ca1e18bd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='View All'])[1]/following::button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glide-arrow right-arrow glide-nav js-nextSlideNav</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-glide-dir</name>
      <type>Main</type>
      <value>></value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Start Slideshow</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tracking-zone</name>
      <type>Main</type>
      <value>gallery</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            Start Slideshow
                            
                              Next
                              
                            
                        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;wf-sourcesanspro-n7-inactive wf-sourcesanspro-n6-inactive wf-sourcesanspro-n4-inactive wf-sourcesanspro-i4-inactive wf-inactive&quot;]/body[@class=&quot;template-gallery node- mdex-test karma-site-container&quot;]/div[@class=&quot;container-full-width karma-below-banner karma-site-container&quot;]/div[@class=&quot;gallery-main-container karma-content-container railDockSection-0&quot;]/div[@class=&quot;component gallery-test grid-b-container karma-main-column galleryTest--hasTitleSlide rendered initialized&quot;]/div[@class=&quot;gallery-container&quot;]/div[@class=&quot;glide title-slide glide--ltr glide--slider glide--swipeable&quot;]/div[@class=&quot;glide-toolbar&quot;]/nav[@class=&quot;glide-controls&quot;]/button[@class=&quot;glide-arrow right-arrow glide-nav js-nextSlideNav&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='View All'])[1]/following::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Share'])[14]/following::button[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='simple syrup'])[1]/preceding::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[3]</value>
   </webElementXpaths>
</WebElementEntity>
