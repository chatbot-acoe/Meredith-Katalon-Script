<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Applications                      View All</name>
   <tag></tag>
   <elementGuidId>02694353-d41d-492b-8ff1-3fdf2281c7f0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Share'])[14]/following::button[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glide-view-all view-all-btn</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Show all slides</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tracking-zone</name>
      <type>Main</type>
      <value>view-all</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                  Applications
    
                  View All
                
                        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;wf-sourcesanspro-n7-inactive wf-sourcesanspro-n6-inactive wf-sourcesanspro-n4-inactive wf-sourcesanspro-i4-inactive wf-inactive&quot;]/body[@class=&quot;template-gallery node- mdex-test karma-site-container&quot;]/div[@class=&quot;container-full-width karma-below-banner karma-site-container&quot;]/div[@class=&quot;gallery-main-container karma-content-container railDockSection-0&quot;]/div[@class=&quot;component gallery-test grid-b-container karma-main-column galleryTest--hasTitleSlide rendered initialized&quot;]/div[@class=&quot;gallery-container&quot;]/div[@class=&quot;glide glide--ltr glide--slider glide--swipeable recipe-slide&quot;]/div[@class=&quot;glide-toolbar&quot;]/nav[@class=&quot;glide-controls&quot;]/button[@class=&quot;glide-view-all view-all-btn&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Share'])[14]/following::button[2]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pin'])[15]/following::button[3]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start Slideshow'])[1]/preceding::button[1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[2]</value>
   </webElementXpaths>
</WebElementEntity>
